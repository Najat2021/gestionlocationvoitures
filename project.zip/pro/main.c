#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <gtk/gtk.h>
#define TAILLE_MAX 1000
typedef struct {
	int jour;
	int mois;
	int annee;
}date;
typedef struct
{
	int IdVoiture;
    int nbplaces;
	int prixjour;
	char marque[15];
	char nomVoiture[15];
	char couleur[10];
	char EnLocation[4];
	}voiture;
	typedef struct {
		int numContrat;
		int idVoiture;
		int idClient;
		date debut;
		date fin;
		int cout;
	}contrat;
	typedef struct {
		int idClient;
		char nom[20];
		char prenom[20];
		char cin[8];
		char adresse[15];
		int telephone;
	}client;
	GtkBuilder *builder;
  //menu principal
  GtkWidget *window, *butt1, *butt2, *butt3, *butt4;
  //location
  GtkWidget *a, *a1,*a2,*a3,*a4, *a5, *a6;
  /*gestion voiture*/
       //window:
    GtkWidget *b, *b1, *b2, *b3, *b4, *b5;
    /*gestion client*/
       //window:
    GtkWidget *c, *c1, *c2,*c3, *c4, *c5;
	// jai fait la declaration de cett fonction ici car sinon elle continue a me dire qu'elle faut la declarer avant .
	void GestionDeVoiture(void);
	// ************************ Fonction Menu qui fait l'appel au autres fonctions *******************************

//*************************** fonction listes de voiture qui fait afficher les voitures qui sont dans le fichier ListeDeVoitures **************************
	void reteura(){
menu_principal();
gtk_widget_destroy(a);
}
void reteurb(){
menu_principal();
gtk_widget_destroy(b);
}
void reteurc(){
menu_principal();
gtk_widget_destroy(c);
}
void p(){
    printf("jjjjj");
}

	// jai fait la declaration de cett fonction ici car sinon elle continue a me dire qu'elle faut la declarer avant .
	void GestionDeVoiture(void);
	// ************************ Fonction Menu qui fait l'appel au autres fonctions *******************************

//*************************** fonction listes de voiture qui fait afficher les voitures qui sont dans le fichier ListeDeVoitures **************************
	void Liste_Voiture(void)
   {
       gtk_widget_destroy(b);
     FILE* fichier = NULL;
      char chaine[TAILLE_MAX];
      fichier = fopen("ListeDesVoiture.txt","r");
      if (fichier != NULL)
  {
  	          printf("--------------------------------------------------------------------------------\n");
			  printf("  ID ----  MARQUE ----- NOM  ----- COULEURE ---- NBR PLACE ---- PRIX ---- ETAT \n");
			  printf("--------------------------------------------------------------------------------\n");
   	while(fgets(chaine,1000,fichier)!=NULL)
			{

			printf("%s   \n",chaine);
		}

    fclose(fichier);
     }
     int indx;
     printf("\n entrer 1 pour roteur :");
     scanf("%d",&indx);
     if(indx==1) gestion_voiture();
   }
//************************************fonction Ajouter Voiture ****************************************
  void Ajouter_Voiture(void)
{
    gtk_widget_destroy(b);
	int N,i;
	voiture T;
	FILE* liste = NULL;
	liste = fopen("ListeDesVoiture.txt", "a+");
	printf("\n\t\tsaisir le nombre des voiture vou souhaite a ajouter :  ");
	scanf("%d",&N);
if (liste != NULL)
{
    	for(i=0;i<N;i++)
			{

			printf("\n\t\t\t Voiture %d :\n\n",i+1);
			do {
			printf("\t ID           :  ");
			scanf(" %d",&T.IdVoiture);}while(T.IdVoiture<0 || T.IdVoiture>9999);
			printf("\t la marke     :  ");
			scanf("%s",T.marque);
			printf("\t le nom       :  ");
			scanf("%s",T.nomVoiture);
			printf("\t couleur      :  ");
			scanf("%s",T.couleur);
			do{
			printf("\t nbr de place :  ");
			scanf("%d",&T.nbplaces);
			}while(T.nbplaces<0 || T.nbplaces>7);
			printf("\t Prix jour    :  ");
			scanf("%d",&T.prixjour);
			printf("\t l'etat ?     :  ");
			scanf("%s",T.EnLocation);
			fprintf(liste,"\n %d     %s       %s        %s             %d          %d       %s",T.IdVoiture,T.marque,T.nomVoiture,T.couleur,T.nbplaces,T.prixjour,T.EnLocation);
		    }
		}
		fclose(liste);
gestion_voiture();
}
//************************************Fonction Modifier Voiture ********************************************
void Modifier_Voiture(void)
	{
	    gtk_widget_destroy(b);
		voiture V;
		char chaine[1000];
		FILE *F=NULL;
		int ID,N,i=0;// la variable N va etre etulisee pour stocker le choix que l'etulisateur va saisie pour specifier quell chose il va modifier
		F=fopen("ListeDesVoiture.txt","r");
		if(F!=NULL)
       {
		  while (!feof(F))//en va lister les Voitures pour que l'etulisateur peut choisie l'Id de la voiture qu'il veut modifier
    {
    fscanf(F,"%d     %s       %s        %s             %d          %d       %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
    printf("\n%d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
   }
		   fclose(F);
	    printf("\n \n \tsaisire le ID du voiture vous souhait a modifier : ");
		scanf("%d",&ID);
		FILE *file=NULL;
		file=fopen("Tmp.txt","a");
		F=fopen("ListeDesVoiture.txt","r");
		while(!feof(F))
			{
				fscanf(F,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
			  if(V.IdVoiture!=ID)
			  {
			  	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);

			  }
			 else
			{
				do{
				printf("\t Quelle information vouler vous modifier : \n");
				printf("\n\t \t1- Id               : ");
				printf("\n\t \t2- Marque           : ");
				printf("\n\t \t3- Nom du voiture   : ");
				printf("\n\t \t4- Couleur          : ");
				printf("\n\t \t5- Nombre de places : ");
				printf("\n\t \t6- Prix Jour        : ");
				printf("\n\t \t7- En location ?    : \n");
				printf("\t\t\tChoix : ");
				scanf("%d",&N);
			}while(N<1 ||N>7);

			switch(N)
			{
				case 1 : system("cls");
				do{
				printf("\t\t Neauvau ID    : ");
				scanf("%d",&V.IdVoiture);
			}while(V.IdVoiture<0 || V.IdVoiture>9999);// en a fait une boucle do while pour controller la saisie d'etulisateur
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 2 : system("cls");
				printf("\t\t Neavelle Marque   : ");
				scanf("%s",V.marque);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 3 : system("cls");
				printf("\t\t Neavau Nom   : ");
				scanf("%s",V.nomVoiture);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 4 : system("cls");
				printf("\t\t Neavelle Couleur   : ");
				scanf("%s",V.couleur);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 5 : system("cls");
				do{
				printf("\t\t Neavelle Nombre de places    : ");
				scanf("%d",&V.nbplaces);
			      }while(V.nbplaces<0 || V.nbplaces>7);// meme chose ici , controler le nombre de places ne doit pas depacer 7 places
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 6 : system("cls");
				printf("\t\t Neauvau Prix   : ");
				scanf("%d",&V.prixjour);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 7 : system("cls");
				printf("\t\t Neavelle Etat   : ");
				scanf("%s",V.EnLocation);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
			}


			}
		}
		if(i==1)
		{
			printf("\n\t la modification a bien ete effectuee .");
		}
		else
		printf("\n\t Le Id que vous aves saisie n'est pas valide , veuller reessayer a neauvau .");
		fclose(F);
		fclose(file);
		remove("ListeDesVoiture.txt");
		rename("Tmp.txt","ListeDesVoiture.txt");
	}
	gestion_voiture();

}//********************************************** fenction Supprimer Voiture *******************************************************

void Supprimer_Voiture(void)
	{

	    gtk_widget_destroy(b);
		voiture V;
		FILE *F=NULL;
		FILE *G=NULL;
		int ID,i=0,rep;
		char chaine[1000];
		F=fopen("ListeDesVoiture.txt","r");
		if(F==NULL)
		{
			printf("ERREURE");
		}
		else{ //en va lister les voiture pour que l'utilisateur peut choisir le Id du voiture qu'il veut supprimer
			while(fgets(chaine,1000,F)!=NULL)
			{
			printf("  %s  \n",chaine);
		}
		fseek(F,0,SEEK_SET);// en met le curseur au debut du fichier pour noua permet de faire parcourire le fichier une autre fois en place de le fermer et l'ouvre again .
		printf("\n\n\tsaisire le ID du voiture vous souhait a supprimer : ");
		scanf("%d",&ID);
		printf("\t Voullez vous vraiment supprimer cette voiture ? 1/0 : ");
		scanf("%d",&rep);
		if(rep==1)
		{
		G=fopen("tmp.txt","w");
	      while(fgets(chaine,1000,F)!=NULL)
	      {
	      	if(fscanf(F,"%d %s %s %s  %d  %d  %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
	      	  if(V.IdVoiture!=ID)
	      	  {
	      	  	fprintf(G,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
	      	  	i=1;
		      }
	}
     }

 }
    if(i==1)
		{
			printf("\n\t la suppression a bien ete effectuee .");
		}
		else
		printf("\n\t Le Id que vous aves saisie n'est pas valide , veuller reessayer a neauvau .");
	fclose(F);
	fclose(G);
	remove("ListeDesVoiture.txt");
    rename("tmp.txt","ListeDesVoiture.txt");
    gestion_voiture();

}
// **************************************** Menu Gestion Voiture qui fait l'appelle aux fonctions precedents*******************************************

//******************************** Liste des Clients ******************************************
void Liste_Clients(void)
   {
       gtk_widget_destroy(c);
      FILE* F = NULL;
      char chaine[TAILLE_MAX]="";
      F = fopen("Clients.txt","r");
      if (F != NULL)
  {
  	printf("-------------------------------------------------------------------------\n");
  	printf(" ID_CLIENT ---- NOM ---- PRENOM ---- CIN ---- ADDRESS ---- TELEPHONE ----\n");
  	printf("-------------------------------------------------------------------------");
    while (fgets(chaine, TAILLE_MAX,F)!=NULL)
    {
     printf("%s   \n", chaine);
   }
    fclose(F);
     }
     int indx;
     printf("entrer 1 pour roteur:");
     scanf("%d",&indx);
     if(indx==1) gestion_client();
   }
//******************************** Ajouter Client **********************************
	void Ajouter_Client(void)
	{
	    gtk_widget_destroy(c);
		FILE* F=NULL;
		F=fopen("Clients.txt","a+");
		int N,i,j;
	    client T[50];
	    if(F!=NULL)
	    {
	    	printf("\t\t combient de Clients vous souhaite a ajouter ? : ");
	    	scanf("%d",&N);
	    	for(i=0;i<N;i++)
	    	{
	    		printf("\t \t\t\t Client %d :\n",i+1);
	    		printf("\t Id client        : ");
	    		scanf("%d",&T[i].idClient);
	    		printf("\t Nom              : ");
	    		scanf("%s",T[i].nom);
	    		printf("\t Prenom           : ");
	    		scanf("%s",T[i].prenom);
	    		printf("\t CIN              : ");
	    		scanf("%s",T[i].cin);
	    		printf("\t Adresse          : ");
	    		scanf("%s",T[i].adresse);
	    		printf("\t Telephone        : ");
	    		scanf("%d",&T[i].telephone);
	    		fprintf(F,"\n   %d       %s     %s    %s    %s     %d ",T[i].idClient,T[i].nom,T[i].prenom,T[i].cin,T[i].adresse,T[i].telephone);
			}
			fclose(F);
		}

//******************************* Modifier Client *******************************
   gestion_client();
   }
   void Modifier_Client(void)
   {
       gtk_widget_destroy(c);
   	  client C;
   	  char chaine[1000];
   	  int Id,i=0,N;// la variable Id on va l'tilise pour stocker le Id du voiture que l'utilisateur va choisie
		 // la variable i est pour connaitre si la modificatioon est bien faite ou non
		 // variable N est pour stocker le choie d'utilisateur ;
   	  FILE *F=NULL,*G=NULL;
   	  F=fopen("Clients.txt","r");
   	  if(F!=NULL)
   	  {
   	  	 while (fgets(chaine, TAILLE_MAX,F)!=NULL)
        {
           printf("%s   \n", chaine);
	    }
     }
    fclose(F);
	 printf("\n\t\t saisire le ID du Client que vous souhait modifier : ");
	 scanf("%d",&Id);

	 F=fopen("Clients.txt","r");
	  if(F!=NULL)
   	  {
   	  	G=fopen("tmp.txt","w");
   	  	if(G!=NULL)
   	  	{
   	  	  while (!feof(F))
        {
        	if(fscanf(F,"%d %s %s %s %s %d",&C.idClient,C.nom,C.prenom,C.cin,C.adresse,&C.telephone)!=EOF)
        	{

        	if(C.idClient!=Id)
        	{
        		fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
			}
        	if(C.idClient==Id)
        	{
        		do
        		{
        		printf("\n \t     Veuiller choisire Ce que Vous vOuler Modifier  : \n");
        		printf("\t\t\t Id        ------------- 1\n");
        		printf("\t\t\t Nom       ------------- 2\n");
        		printf("\t\t\t Prenom    ------------- 3\n");
        		printf("\t\t\t CIN       ------------- 4\n");
        		printf("\t\t\t Address   ------------- 5\n");
        		printf("\t\t\t Telephone ------------- 6\n");
        		printf("\t\t\t\t CHOIX : ");
        		scanf("%d",&N);
        		}while(N<1 || N>6);

        		switch(N)
        		{
        			case 1 : system("cls");
        			do {
					printf("\t \t neauvau ID       : ");
					scanf("%d",&C.idClient);
				     }while(C.idClient <0 || C.idClient>9999);
			      	fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 2 : system("cls");
                    printf("\t\t neauvau Nom       : ");
                    scanf("%s",C.nom);
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 3 : system("cls");
                    printf("\t\t neauvau Prenom    : ");
                    scanf("%s",C.prenom);
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 4 : system("cls");
                    printf("\t\t neauvau CIN       : ");
                    scanf("%s",C.cin);
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 5 : system("cls");
                    printf("\t\t neauvelle Address : ");
                    scanf("%s",C.adresse);
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 6 : system("cls");
					printf("\t\t neauvau Telephone : ");
                    scanf("%d",&C.telephone);

                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;

						}

        		i=1;
			}
       }
   }
   }
   if(i==1)
   {
   	printf("\n\t la modifiction a bien ete effectue :");
   }
  }
   fclose(F);
   fclose(G);
   remove("Clients.txt");
   rename("tmp.txt","Clients.txt");
gestion_client();
}
//************************************ Supprimer Client *******************************************
   void Supprimer_Client(void)
{
    gtk_widget_destroy(c);
	client  P;
	char chaine[1000];
	FILE *F=NULL;
	FILE *G=NULL;
	int id,i=0,rep;
    F=fopen("Clients.txt","r");
    if(F==NULL)
	printf("erreur\n");

    else
    {
		G=fopen("tmp.txt","w");
        if(G==NULL)
             printf("erreur\n");
        else
     { // en va afficher les Clients pour que l'utilisateur peut choisire d'entre eux
  	     while (fgets(chaine, TAILLE_MAX,F)!=NULL)
        {
           printf("%s   \n", chaine);
	     }
	    fseek(F,0,SEEK_SET); // en remet le cursure vers le debut
      	printf("\n\n\t entrer le id de client qui vous voulez supprimer: ");
        scanf("%d",&id);
        	printf("\n\t Voullez vous vraiment supprimer ce client ? 1/0 : ");
		scanf("%d",&rep);
		if(rep==1)
		{

	while(fgets(chaine,1000,F)!=NULL)

	{
		if(fscanf(F,"%d %s %s %s %s %d",&P.idClient,P.nom,P.prenom,P.cin,P.adresse,&P.telephone)!=EOF)
		{
		   if(P.idClient!=id)
	      fprintf(G,  "\n  %d       %s     %s    %s    %s     %d ",P.idClient,P.nom,P.prenom,P.cin,P.adresse,P.telephone);
	      i=1;
	   }
    }
  }
   }
   if(i==1)
     printf("\n\t\tla suppression de ce Client a ete effectuee avec succes ! ");

    fclose(F);
	fclose(G);
 	remove("Clients.txt");
	rename("tmp.txt","Clients.txt");

 }
 gestion_client();
//********************************************** Menu Gestion Client ***************************************************
}

		void Visualiser_Contrat(void)
	{
	    gtk_widget_destroy(a);
		int ID,c=0;// la variable C est etulisee pour connaitre si le ID que l'utilisateur a entrer est valide ou nn .
		contrat C;
		char chaine[1000];
		FILE *F=NULL;
		F=fopen("Contrat.txt","r");
		if(F!=NULL)
		{
			printf("\n \t saisire votre Contra_ID SVP : ");
			scanf("%d",&ID);
			do{

          	if(fscanf(F," %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",&C.numContrat,&C.idVoiture,&C.idClient,&C.debut.jour,&C.debut.mois,&C.debut.annee,&C.fin.jour,&C.fin.mois,&C.fin.annee,&C.cout)!=EOF)

            if(C.numContrat==ID)
			    {
			    	printf("\n\t \t vous etes deja inscrit avec nous et voici votre contrat : \n");
			    	printf("\n\t\t NumContrat  || ID_Voiture   || ID_Client   || Date debut    || Date fin    || Cout ");
			    	printf("\n\t\t ------------  --------------  -------------  ---------------  -------------  ------");
			    	printf("\n\t\t %d        || %d         || %d        || %d/%d/%d    || %d/%d/%d  || %d DH\n\t",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);
			       c=1;
				}
			}while(fgets(chaine,1000,F)!=NULL);
			if(c==0)
					printf(" Ce ID que vous aves entres n'existe pas , si vous voulez vous pouvez passer au menu precedent pour vous Ajouter, Merci.");

			fclose(F);

		}
		else{
			printf("erreur ");
		}
		ocation();
	}
 //cette fonction en l'etuliser pour calculer le Cout de chaque personne, elle a comme parametre le jour de debut et le jour du fn et le prix du voiture selectionee .
	int Cout(int debutj,int finj,int prixV)
	{
		int cout;
		int jour;
		if(finj>debutj)
		{
			jour=finj-debutj;
		}
		else
		{
			jour=30-(debutj-finj);
		}
		cout=jour*prixV;

		return cout;

	}
// cette fonction en l'etulise pour ajouter la cotntra que l'etulisateur va saisir et en va la stocker avec les autres contrats
	void Ajouter_Contrat(int PrixV)
	{
		contrat C;
		FILE *F=NULL,*G=NULL;
		F=fopen("Contrat.txt","a+");
		if(F!=NULL)
		{
			printf("\n\t Num contrat    : ");
			scanf("%d",&C.numContrat);
			printf("\t ID voiture       : ");
			scanf("%d",&C.idVoiture);
			printf("\t ID Client        : ");
			scanf("%d",&C.idClient);
			printf("\t Date debut       : ");
			scanf("%d %d %d",&C.debut.jour,&C.debut.mois,&C.debut.annee);
			printf("\t Date fin         : ");
			scanf("%d %d %d",&C.fin.jour,&C.fin.mois,&C.fin.annee);
			C.cout=Cout(C.debut.jour,C.fin.jour,PrixV);
			fprintf(F,"\n %d   %d   %d   %d/%d/%d   %d/%d/%d   %d Dh",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);
		}
		fclose(F);
	}
	// cette fenction en va l'etuliser pour changer l'attribut "non" du fichier voiture a "oui"
void Ajouter_Oui(int Vid,FILE *H)
	{

		voiture V;
		fclose(H);
		FILE *F=NULL;
		F=fopen("ListeDesVoiture.txt","r");
		if(F!=NULL)
       {
		FILE *file=NULL;
		file=fopen("Tmpl.txt","a");
		while(!feof(F))
			{
				if(fscanf(F,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
				{

			  if(V.IdVoiture!=Vid)
			  {
			  	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
			  }
			 else
			{
				strcpy(V.EnLocation,"oui");
		    	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
		    	printf("\n\t VOTRE CONTAT A BIEN ETE CREE ! MERCI POUR NOUS CHOISIE  .");
			}
		}
	}
		fclose(F);
		fclose(file);
		remove("ListeDesVoiture.txt");
		rename("Tmpl.txt","ListeDesVoiture.txt");
	}

}
//**************************** fenction Louer Voiture *************************************
	void Louer_Voiture(void)
	{
	    gtk_widget_destroy(a);
		date debut,fin;
		client C;
		voiture V;
		int rep;
		contrat Nvcontrat;
		int aide=0,tmp=0,numcontrat,PrixV;
		FILE *F=NULL,*G=NULL,*H=NULL;
		char nom[20],prenom[20];
		int IdVoiture;

		printf("\n\t Veillez entrer les informations suivants : \n");
		printf("\t\t Nom      : ");
		scanf("%s",nom);
		printf("\t\t Prenom   : " );
		scanf("%s",prenom);
		printf("\t\t ID du voiture vous souhaite a louer : ");
		scanf("%d",&IdVoiture);
		F=fopen("Clients.txt","r");
		G=fopen("ListeDesVoiture.txt","r");
		H=fopen("Contrat.txt","r");
		if(F!=NULL)
		{
			do
			{
				fflush(stdin);
				fscanf(F,"  %d       %s     %s    %s    %s     %d",&C.idClient,C.nom,C.prenom,C.cin,C.adresse,&C.telephone);
				if(strcmp(C.nom,nom)==0 && strcmp(C.prenom,prenom)==0)
				{
				   aide=1;
				}
			}while(!feof(F));
			fseek(F,0,SEEK_SET);// en met le cursur vers le debut
		}
			else
			{
				printf("erreure");
			}
			if(G!=NULL);
			{
		    	do
		    	{
			  fscanf(G,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
			  if(V.IdVoiture==IdVoiture)
			  {
	             	tmp=1;
	             	PrixV=V.prixjour;
	             }
		        }while(!feof(G));

			}
			if(G==NULL){
				printf("erreure");
			}
			if(aide==1)
			{
				if(tmp==1)
				{
					fseek(G,0,SEEK_SET);
					do
					{
						if(fscanf(G,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
                      {

						if(strcmp(V.EnLocation,"oui")==0 &&  V.IdVoiture==IdVoiture)
						{
							printf("\n\t CETTE VOITURE EST DEJA LOUER A QULQ'UN , VEULLER CHOISIRE UNE AUTRE , MERCI.");
							fclose(F);
	                     	fclose(G);
	                     	fclose(H);
							break;
						}
							if(strcmp(V.EnLocation,"non")==0 &&  V.IdVoiture==IdVoiture)
						{
							if(H!=NULL)
							{
							Ajouter_Contrat(PrixV);
							Ajouter_Oui(V.IdVoiture,G);

							break;
					     	}


						}

					}
				}while(!feof(G));
			}
				else
				{
					printf("VOU ETES DEJA INSCRIT AVEC NOUS , MAIS LA VOITURE QUE VOUS AVES CHOISIE N'EXISTE PAS ! ");
				}

			}
			else{
				printf("\n VOUS NETES PAS INSCRIT AVEC NOUS ,VOULLEZ VOUS VOUS AJOUTER MAINTENANT ? 1/0 : ");
				scanf("%d",&rep);
				switch (rep)
				{
					case 1 : system("cls");
					  	FILE* F=NULL;
		F=fopen("Clients.txt","a+");
		int N,i,j;
	    client T;
	    if(F!=NULL)
	    {


	    		printf("\t Id client        : ");
	    		scanf("%d",&T.idClient);
	    		printf("\t Nom              : ");
	    		scanf("%s",T.nom);
	    		printf("\t Prenom           : ");
	    		scanf("%s",T.prenom);
	    		printf("\t CIN              : ");
	    		scanf("%s",T.cin);
	    		printf("\t Adresse          : ");
	    		scanf("%s",T.adresse);
	    		printf("\t Telephone        : ");
	    		scanf("%d",&T.telephone);
	    		fprintf(F,"\n   %d       %s     %s    %s    %s     %d ",T.idClient,T.nom,T.prenom,T.cin,T.adresse,T.telephone);
			}
			fclose(F);
					break;
					case 0 : system("cls");
					break;
					default : printf("veiller entrer 1 ou 0 ");
				}
			}
		fclose(H);
		fclose(F);
		fclose(G);
		gestion_voiture();

	}
	// cette fonction la en va l'etuliser pour changer "oui" a "non", c a d rendre la voiture disponible a louer
		void Ajouter_non(int Vid ,FILE* H)
	{
		voiture V;
		fclose(H);
		FILE *F=NULL,*file=NULL;
		F=fopen("ListeDesVoiture.txt","r");
		file=fopen("Tmp.txt","a");
		if(F!=NULL)
       {

		while(!feof(F))
			{
				fscanf(F," %d     %s       %s        %s             %d          %d       %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
			  if(V.IdVoiture!=Vid)
			  {
			  	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
			  }
			 if(V.IdVoiture==Vid)
			{

				strcpy(V.EnLocation,"non");
		    	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);

			}
		}
		fclose(F);
		fclose(file);
		remove("ListeDesVoiture.txt");
		rename("Tmp.txt","ListeDesVoiture.txt");
 	}
}
// cette fonction en va l'etuliser pour suprimer la contrat apres que l'utilisateur retourner la voiture .elle va travailler automatiquement
void Supprimer_contrat(int numcontrat)
{
	contrat C;
	FILE *F=NULL,*G=NULL;
	char chaine[1000];
	F=fopen("Contrat.txt","r");
	G=fopen("tmp.txt","w");
	if(F!=NULL)
	{
		do
		{ if(fscanf(F,"%d   %d   %d   %d/%d/%d   %d/%d/%d   %d",&C.numContrat,&C.idVoiture,&C.idClient,&C.debut.jour,&C.debut.mois,&C.debut.annee,&C.fin.jour,&C.fin.mois,&C.fin.annee,&C.cout)!=EOF)
          {
		   if(C.numContrat!=numcontrat)
		   {
		   	if(G!=NULL)
		   	{
		   		fprintf(G,"\n %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);

			   }
		   }

	}
		}while(fgets(chaine,1000,F));
	}

	printf("\n \t la contrat a bien ete supprimee ");
	fclose(F);
	fclose(G);
	remove("Contrat.txt");
	rename("tmp.txt","Contrat.txt");
}
void suppr_contrat(){
    gtk_widget_destroy(a);
    int Id;
printf("\n\t\t Entrer votre contrat ID pour la supprimer : ");
		 scanf("%d",&Id);
		 Supprimer_contrat(Id);
		 ocation();
}
// cella en va l'utoiliser pour supprimer le client de la liste des clients apres qu'il retourner la voiture
void supprimer_Client(int IdClient)
{
	client C;
	FILE *F=NULL,*G=NULL;
	F=fopen("Clients.txt","r");
	G=fopen("tmp.txt","w");
	if(F!=NULL)
	{
		do
		{
			   if( fscanf(F," %d       %s     %s    %s    %s     %d",&C.idClient,C.nom,C.prenom,C.cin,C.adresse,&C.telephone)!=EOF)
        {
		   if(C.idClient!=IdClient)
		   {
		   	if(G!=NULL)
		   	{
		   		fprintf(G,"\n  %d       %s     %s    %s    %s     %d",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
			   }
		   }
	}
		}while(!feof(F));
	}
	printf("\n \t le Client a bien ete supprimee ");
	fclose(F);
	fclose(G);
	remove("Clients.txt");
	rename("tmp.txt","Clients.txt");
}
//******************************* Retourner Voiture **********************************
void Retourner_Voiture(void)
{
    gtk_widget_destroy(a);
	int Idvoiture,Numcontrat,Idclient,pos;
	int aide1,aide2,aide3;
	voiture V;
	client C;
	contrat T;
	FILE *F=NULL,*G=NULL,*H=NULL;
	F=fopen("ListeDesVoiture.txt","r");
	G=fopen("Clients.txt","r");
	H=fopen("Contrat.txt","r");
	printf("\t\t Veiller entre les information suivant : \n");
	printf("\t Numero de Contrat     : ");
	scanf("%d",&Numcontrat);
	printf("\t Id du Voiture         : ");
	scanf("%d",&Idvoiture);
	printf("\t Id Client             : ");
	scanf("%d",&Idclient);
	if(G!=NULL)
	{
		do
		{
			if( fscanf(G," %d       %s     %s    %s    %s     %d",&C.idClient,C.nom,C.prenom,C.cin,C.adresse,&C.telephone)!=EOF)
			{

				if(Idclient==C.idClient)
				aide1=1;
			}
		}while(!feof(G));

		fclose(G);
	}
	else printf("errure");
	if(H!=NULL)
	{
		while(!feof(H))
		{
			if(fscanf(H,"%d   %d   %d   %d/%d/%d   %d/%d/%d   %d",&T.numContrat,&T.idVoiture,&T.idClient,&T.debut.jour,&T.debut.mois,&T.debut.annee,&T.fin.jour,&T.fin.mois,&T.fin.annee,&T.cout)!=EOF)
			if(Numcontrat==T.numContrat)
			aide2=1;
		}

		fclose(H);
	}
		else printf("errure");
	if(F!=NULL)
	{
		while(!feof(F))
		{
			if(fscanf(F,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
			if(Idvoiture==V.IdVoiture)
			aide3=1;

		}

		fclose(F);
	}
		else printf("errure");
	F=fopen("ListeDesVoiture.txt","r");
	if(aide1==1)
	{
	   if(aide2==1)
	   {
	        if(aide3==1)
	          {
			    if(F!=NULL)
	{
		do
		{
			if(fscanf(F,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
         {

			if(V.IdVoiture==Idvoiture)
			{

				Ajouter_non(Idvoiture,F);
				Supprimer_contrat(Numcontrat);
				supprimer_Client(Idclient);
				break;
							}
		}
		}while(!feof(F));
	}
}
}
}

	if(aide1!=1) printf("\n\t Ce client n'existe pas veiller re choisire un ID CLIent valide svp ");
	if(aide2!=1) printf("\n\t Cette Contra n'existe pas veiller rechoisire un ID Contrat valide svp");
	if(aide3!=1) printf("\n\t cette voiture n'existe pas veiller rechoisire un ID voiture valide svp");
	printf("\n\n\t MERCI POUR NOUS CHOISIE , A BIENTOT !");
	fclose(F);
ocation();
}
// ***************************************** Modifier Contrat ******************************************
void Modifier_Contrat(void)
{
    gtk_widget_destroy(a);
	int Id,prix;
	contrat C;
	voiture V;
	FILE *F=NULL,*G=NULL,*H=NULL;
	F=fopen("Contrat.txt","r");
	G=fopen("tmp.txt","w");
	H=fopen("ListeDesVoiture.txt","r");
	printf("\n\t\t Entrer le numero du contrat que vous souhaite la modifier : ");
	scanf("%d",&Id);
	if(F!=NULL)
	{
		do
		{
	       fscanf(F," %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",&C.numContrat,&C.idVoiture,&C.idClient,&C.debut.jour,&C.debut.mois,&C.debut.annee,&C.fin.jour,&C.fin.mois,&C.fin.annee,&C.cout);
           if(C.numContrat==Id)
           {
           	 printf("\n\t\tcett contrat commance le %d/%d/%d ,Entrer La Nouvelle date de fin    : ",C.debut.jour,C.debut.mois,C.debut.annee);
           	 scanf("%d %d %d",&C.fin.jour,&C.fin.mois,&C.fin.annee);
           	 if(H!=NULL)
           	 {
           	 	do
           	     { fflush(stdin);
					fscanf(H,"\n %d     %s       %s        %s             %d          %d       %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
	                if(V.IdVoiture==C.idVoiture)
	                {
	                	prix=V.prixjour;
					}
				}while(!feof(H));
			}
			else
			{
				printf("erreure");
				}
           	 if(G!=NULL)
           	 {
           	 	C.cout=Cout(C.debut.jour,C.fin.jour,prix);
           	 	fprintf(G,"\n %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);
				}
				else
				{
					printf("erreure");
				}
		   }
		   else
		   {

           	 fprintf(G,"\n %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);

		   }
		}while(!feof(F));
	}
	printf("\n\t la modification a bien ete effectuee !");
	fclose(F);
	fclose(G);
	fclose(H);
	remove("Contrat.txt");
	rename("tmp.txt","Contrat.txt");
	ocation();
}




void ocation(){
    builder=gtk_builder_new_from_file("PROJECT.glade");

    /*********************************location*********************************/
       //window:
    a=gtk_builder_get_object(builder,"a");
       //buttons
    a1=gtk_builder_get_object(builder,"a1");
    g_signal_connect (a1, "clicked", G_CALLBACK (Visualiser_Contrat), NULL);
    a2=gtk_builder_get_object(builder,"a2");
    g_signal_connect (a2, "clicked", G_CALLBACK (Louer_Voiture), NULL);
     a3=gtk_builder_get_object(builder,"a3");
    g_signal_connect (a3, "clicked", G_CALLBACK (Retourner_Voiture), NULL);
     a4=gtk_builder_get_object(builder,"a4");
    g_signal_connect (a4, "clicked", G_CALLBACK (Modifier_Contrat), NULL);
     a5=gtk_builder_get_object(builder,"a5");
    g_signal_connect (a5, "clicked", G_CALLBACK (suppr_contrat), NULL);
     a6=gtk_builder_get_object(builder,"a6");
    g_signal_connect (a6, "clicked", G_CALLBACK (reteura), NULL);
    gtk_widget_destroy(window);
    gtk_widget_show_all(a);

}
void gestion_voiture(){
    builder=gtk_builder_new_from_file("PROJECT.glade");


       /*********************************gestion cvoiture*********************************/
       //window:
    b=gtk_builder_get_object(builder,"b");
       //buttons
    b1=gtk_builder_get_object(builder,"b1");
    g_signal_connect (b1, "clicked", G_CALLBACK (Liste_Voiture), NULL);
    b2=gtk_builder_get_object(builder,"b2");
    g_signal_connect (b2, "clicked", G_CALLBACK (Ajouter_Voiture), NULL);
    b3=gtk_builder_get_object(builder,"b3");
    g_signal_connect (b3, "clicked", G_CALLBACK (Modifier_Voiture), NULL);
    b4=gtk_builder_get_object(builder,"b4");
    g_signal_connect (b4, "clicked", G_CALLBACK (Supprimer_Voiture), NULL);
    b5=gtk_builder_get_object(builder,"b5");
    g_signal_connect (b5, "clicked", G_CALLBACK (reteurb), NULL);
    gtk_widget_show_all(b);
    gtk_widget_destroy(window);

}

void gestion_client(){
    builder=gtk_builder_new_from_file("PROJECT.glade");

    /*********************************gestion client*********************************/
       //window:
    c=gtk_builder_get_object(builder,"c");
       //buttons
    c1=gtk_builder_get_object(builder,"c1");
    g_signal_connect (c1, "clicked", G_CALLBACK (Liste_Clients), NULL);
    c2=gtk_builder_get_object(builder,"c2");
    g_signal_connect (c2, "clicked", G_CALLBACK (Ajouter_Client), NULL);
    c3=gtk_builder_get_object(builder,"c3");
    g_signal_connect (c3, "clicked", G_CALLBACK (Modifier_Client), NULL);
    c4=gtk_builder_get_object(builder,"c4");
    g_signal_connect (c4, "clicked", G_CALLBACK (supprimer_Client), NULL);
    c5=gtk_builder_get_object(builder,"c5");
    g_signal_connect (c5, "clicked", G_CALLBACK (reteurc), NULL);
    gtk_widget_show_all(c);
    gtk_widget_destroy(window);
}


void quitte(){
    g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_destroy(window);
}
void menu_principal(){
builder=gtk_builder_new_from_file("PROJECT.glade");

    /*********************************menu principal*********************************/
       //window:
    window=gtk_builder_get_object(builder,"window");
       //buttons
    butt1=gtk_builder_get_object(builder,"butt1");
    g_signal_connect (butt1, "clicked", G_CALLBACK (ocation), NULL);
    butt2=gtk_builder_get_object(builder,"butt2");
    g_signal_connect (butt2, "clicked", G_CALLBACK (gestion_voiture), NULL);
     butt3=gtk_builder_get_object(builder,"butt3");
    g_signal_connect (butt3, "clicked", G_CALLBACK (gestion_client), NULL);
     butt4=gtk_builder_get_object(builder,"butt4");
    g_signal_connect (butt4, "clicked", G_CALLBACK (quitte), NULL);
    gtk_widget_show_all(window);

}



	int main(int argc, char **argv){
    gtk_init(&argc,&argv);



  /*________le fichier glade________*/
    builder=gtk_builder_new_from_file("PROJECT.glade");


    menu_principal();
    gtk_main();

     return 0;
    }
